import React, { useEffect, useRef, useMemo } from "react";
import style from "./ToDoItemCreate.module.scss";
import { ItemPostAction } from "../../store/ToDoItemsReducer";
import { useDispatch } from "react-redux";
import itemsSync from "../../server/sync";
import { FiMoon } from "react-icons/fi";
import { MdAddBox, MdWbSunny } from "react-icons/md";

export default function ToDoItemCreate({ colourMode, setColourMode }) {
    const dispatch = useDispatch();
    const sync = new itemsSync();

    const colour = useMemo(() => {
        return {
            color: colourMode === "white" ? "black" : "white",
            backgroundColor: colourMode,
            borderColor: colourMode === "white" ? "black" : "white",
        };
    }, [colourMode]);

    let buffer = {
        title: "",
        content: "",
    };
    function inputAction(event) {
        buffer[event.currentTarget.id] = event.currentTarget.innerText;
        event.currentTarget.style.opacity = "1";
    }
    function addToStore() {
        sync.postItem({ ...buffer })
            .then(response => {
                dispatch(ItemPostAction({ ...response.newItem }))
            })
            .then(() => {
                buffer.title = "";
                buffer.content = "";
                document.getElementById("title").innerText = "";
                document.getElementById("content").innerText = "";
            })

    }
    function Field(placeholder, styleClass, id) {
        const fieldRef = useRef(null);
        function setDefaultField() {
            if (fieldRef.current.innerText === "") {
                fieldRef.current.innerText = placeholder;
                fieldRef.current.style.opacity = ".7";
            }
        }
        useEffect(() => {
            setDefaultField();
        });
        return (
            <div
                id={id}
                ref={fieldRef}
                className={styleClass}
                contentEditable={true}
                suppressContentEditableWarning={true}
                onSelect={() => {
                    if (fieldRef.current.innerText === placeholder) {
                        fieldRef.current.innerText = " ";
                        fieldRef.current.style.color = colour;
                    }
                }}
                onBlur={setDefaultField}
                onInput={(e) => inputAction(e)}
                style={colour}
            />
        );
    }
    return (
        <>
            <div
                style={colour}
                className={style.create__wrapper}
            >
                <div
                    style={colour}
                    className={style.create__wrapper__inputs}
                >
                    {Field("Title", style.create__wrapper__name, "title")}
                    {Field(
                        "Content",
                        style.create__wrapper__name,
                        "content"
                    )}
                </div>
                <div style={colour} className={style.create__wrapper__buttons}>
                    <MdAddBox
                        id="add__btn"
                        onClick={addToStore}
                        style={colour}
                        className={style.create__wrapper__buttons__btn}
                    />
                    <div
                        className={style.create__wrapper__buttons__btn}
                        style={colour}
                        onClick={() => {
                            setColourMode();
                        }}
                    >
                        {colourMode === "white" ? (
                            <MdWbSunny style={colour} />
                        ) : (
                            <FiMoon style={colour} />
                        )}
                    </div>
                </div>
            </div>
        </>
    );
}
