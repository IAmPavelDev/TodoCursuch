import React, { useEffect, useState } from "react";
import style from "./ToDoItemList.module.scss";
import ToDoItem from "../ToDoItem/ToDoItem";
import { useSelector } from "react-redux";

export default function ToDoItemList({ colourMode }) {
    const [itemsList, setItemsList] = useState();
    const items = useSelector((state) => state);
    useEffect(() => {
        setItemsList(items.map((item, index) =>
            <ToDoItem
                inputName={item.title}
                inputMain={item.content}
                numberInList={index}
                itemId={item.itemId}
                key={item.itemId}
                colourMode={colourMode}
            />
        ))
    }, [setItemsList, colourMode, items])

    return <div style={{ backgroundColor: colourMode }} className={style.list__wrapper}>{itemsList}</div>;
}
