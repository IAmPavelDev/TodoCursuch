import React, { useRef, useState } from "react";
import style from "./ToDoItem.module.scss";

import { ItemDeleteAction, ItemEditAction } from "../../store/ToDoItemsReducer";
import { useDispatch } from "react-redux";

import {
    MdOutlineEditOff,
    MdOutlineModeEditOutline,
    MdDeleteForever,
    MdSave
} from "react-icons/md";
import { useEffect } from "react";
import itemsSync from "../../server/sync";


function Field(data, placeholder, styleClass, colourMode, isEditable, changeHandler) {
    const fieldRef = useRef(null);
    function setDefaultField() {
        if (fieldRef.current.innerText === "") {
            fieldRef.current.innerText = placeholder;
            fieldRef.current.style.color =
                colourMode === "white" ? "black" : "white";
            fieldRef.current.style.opacity = ".7";
        }
    }
    useEffect(() => {
        setDefaultField();
    });
    return (
        <div
            ref={fieldRef}
            className={styleClass}
            contentEditable={isEditable ? "true" : "inherit"}
            suppressContentEditableWarning={true}
            onClick={() => {
                if (
                    fieldRef.current.innerText === placeholder &&
                    isEditable
                ) {
                    fieldRef.current.innerText = " ";
                    fieldRef.current.style.color =
                        colourMode === "white" ? "black" : "white";

                    fieldRef.current.style.opacity = "1";
                }
            }}
            onBlur={setDefaultField}
            onInput={(e) =>
                changeHandler(e.target.innerText !== data, e.target.innerText, placeholder.toLowerCase())
            }
            style={{
                backgroundColor: colourMode,
                color: colourMode === "white" ? "black" : "white",
                borderColor: colourMode === "white" ? "black" : "white",
            }}
        >
            {data}
        </div>
    );
}


export default function ToDoItem({
    inputName,
    inputMain,
    numberInList,
    itemId,
    colourMode,
}) {
    const dispatch = useDispatch();

    const [isEditable, setIsEditable] = useState(false);
    const [isNew, setIsNew] = useState(false);
    const sync = new itemsSync();
    const updateData = {};

    const onChangeHandler = (isNew, data, type) => {
        if (isNew) {
            updateData[type] = data;
        }
        setIsNew(isNew);
    }

    const updateItem = () => {
        sync.updateItem(itemId, updateData)
        .then(response => dispatch(ItemEditAction(response.item)))
        .then(() => setIsNew(false))
    }

    const deleteItem = () => {
        sync.deleteItem(itemId).then(() => {
            dispatch(ItemDeleteAction(itemId))
        })
    }

    return (
        <>
            <div
                style={{
                    backgroundColor: colourMode,
                    color: colourMode === "white" ? "black" : "white",
                    borderColor: colourMode === "white" ? "black" : "white",
                }}
                className={style.ToDoItem__wrapper}
            >
                <div style={{
                    backgroundColor: colourMode,
                }} className={style.ToDoItem__wrapper__data_number}>
                    #{numberInList + 1}
                </div>
                <div
                    style={{
                        backgroundColor: colourMode,
                    }}
                    className={style.ToDoItem__wrapper__data}
                >
                    {Field(
                        inputName,
                        "title",
                        style.ToDoItem__wrapper__data__name,
                        colourMode,
                        isEditable,
                        onChangeHandler
                    )}
                    {Field(
                        inputMain,
                        "Content",
                        style.ToDoItem__wrapper__data__main,
                        colourMode,
                        isEditable,
                        onChangeHandler
                    )}
                </div>
                <div
                    style={{
                        backgroundColor: colourMode,
                    }}
                    className={style.ToDoItem__wrapper__buttons}
                >
                    <div
                        style={{
                            backgroundColor: colourMode,
                        }}
                        onClick={() => setIsEditable(!isEditable)}
                    >
                        {isEditable ? (
                            <MdOutlineEditOff
                                style={{
                                    backgroundColor: colourMode,
                                }}
                            />
                        ) : (
                            <MdOutlineModeEditOutline
                                style={{
                                    backgroundColor: colourMode,
                                }}
                            />
                        )}
                    </div>
                    <div
                        onClick={deleteItem}
                        style={{
                            backgroundColor: colourMode,
                        }}
                    >
                        <MdDeleteForever
                            style={{
                                backgroundColor: colourMode,
                            }}
                        />
                    </div>
                    {isNew ?
                        <div onClick={updateItem}><MdSave /></div> : <></>}
                </div>
            </div>
        </>
    );
}
