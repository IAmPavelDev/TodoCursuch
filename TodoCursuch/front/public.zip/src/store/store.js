import ToDoItemsReducer from "./ToDoItemsReducer";
import { createStore } from "redux";
export const store = createStore(ToDoItemsReducer); 