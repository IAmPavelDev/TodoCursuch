const InitialToDoItemsState = [];
export default function ToDoItemsReducer(
	state = InitialToDoItemsState,
	action
) {
	switch (action.type) {
		case "items/post":
			return [...state, action.payload];
		case "items/edit":
			return [...state.map(item =>
				item.itemId === action.payload.itemId ? action.payload : item)]
		case "items/delete":
			return state.filter(
				(item) => item.itemId !== action.itemId
			);
		default:
			return state;
	}
}

export function ItemEditAction(editData) {
	console.log(editData)
	return { type: "items/edit", payload: editData };
}

export function ItemPostAction(item) {
	return { type: "items/post", payload: item };
}

export function ItemDeleteAction(itemId) {
	return { type: "items/delete", itemId };
}
