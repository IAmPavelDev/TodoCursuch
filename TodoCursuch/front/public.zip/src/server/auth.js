
export const registration = (username, password, confirm) => {
  const request = JSON.stringify({
    username,
    password
  });

  const myHeaders = new Headers();
  myHeaders.append("Content-Type", "application/json");
  myHeaders.append("Access-Control-Allow-Origin", "*");
  myHeaders.append("Access-Control-Allow-Methods", "GET, PUT, PATCH, DELETE, POST");


  const requestOptions = {
    method: "POST",
    headers: myHeaders,
    body: request,
    redirect: "follow",
    mode: "no-cors"
  };

  fetch(
    "http://localhost:5000/api/user/registration",
    requestOptions
  )
    .then(res => res.json())
    .then(data => {
      localStorage.setItem("token", data.token);
      if (data.token) confirm();
    })
    .catch(e => console.error(e))
};

export const login = (username, password, confirm) => {
  const myHeaders = new Headers();
  myHeaders.append("Content-Type", "application/json");
  myHeaders.append("Access-Control-Allow-Origin", "*");
  myHeaders.append("Access-Control-Allow-Methods", "GET, PUT, PATCH, DELETE, POST");

  const request = JSON.stringify({
    username,
    password
  });

  const requestOptions = {
    method: "POST",
    headers: myHeaders,
    body: request,
    redirect: "follow",
    // mode: "no-cors"
  };

  console.log(request)
  fetch(
    "http://localhost:5000/api/user/login",
    requestOptions
  )
    .then((result) => result.json())
    .then(data => {
      localStorage.setItem("token", data.token);
      if (data.token) { confirm() };
    })
    .catch(e => console.error(e))

};
